<?php
require('model.php');

$posts = getPosts();

require('indexView.php');